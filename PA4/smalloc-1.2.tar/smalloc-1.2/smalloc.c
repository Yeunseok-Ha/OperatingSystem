#include <unistd.h>
#include <stdio.h>
#include "smalloc.h" 

sm_container_ptr sm_first = 0x0 ;
sm_container_ptr sm_last = 0x0 ;
sm_container_ptr sm_unused_containers = 0x0 ;

void unused_linked_list(){
	sm_container_ptr itr = 0x0;
	int cond = 0;
	for(itr = sm_first; itr != 0x0; itr = itr->next){
                if(itr->status == Unused){
			sm_unused_containers = itr;
//                        printf("%p->", sm_unused_containers->data);
                }
        }
//        printf("\n");

}
void merge_adjacent_unused(){
	sm_container_ptr itr = 0x0;
	sm_container_ptr tmp = 0x0;
	for(int i = 0; i < 2; i++)
		for(itr = sm_first; itr->next != 0x0; itr = itr->next){
			if(itr->status == Unused && itr->next->status == Unused){
				itr->dsize += itr->next->dsize + sizeof(sm_container_t);
				if(itr->next == sm_last){
					sm_last = itr;
					sm_last->next = 0x0;
					return;
				}
				else{
					itr->next = itr->next->next;
				}
			}
		}
}

void sm_container_split(sm_container_ptr hole, size_t size)
{
	sm_container_ptr remainder = hole->data + size ;

	remainder->data = ((void *)remainder) + sizeof(sm_container_t) ;
	remainder->dsize = hole->dsize - size - sizeof(sm_container_t) ;
	remainder->status = Unused ;
	remainder->next = hole->next ;
	hole->next = remainder ;

	if (hole == sm_last)
		sm_last = remainder ;
}

void * sm_retain_more_memory(int size)
{
	sm_container_ptr hole ;
	int pagesize = getpagesize() ;
	int n_pages = 0 ;

	n_pages = (sizeof(sm_container_t) + size + sizeof(sm_container_t)) / pagesize  + 1 ;
	hole = (sm_container_ptr) sbrk(n_pages * pagesize) ;
	if (hole == 0x0)
		return 0x0 ;

	hole->data = ((void *) hole) + sizeof(sm_container_t) ;
	hole->dsize = n_pages * getpagesize() - sizeof(sm_container_t) ;
	hole->status = Unused ;

	return hole ;
}

void * smalloc(size_t size) 
{
	sm_container_ptr hole = 0x0 ;
	sm_container_ptr itr = 0x0 ;
	size_t min = size + sizeof(sm_container_t);
	int cond = 0;
	for (itr = sm_first ; itr != 0x0 ; itr = itr->next) {
		if (itr->status == Busy)
			continue ;

		if (size == itr->dsize) {
			// a hole of the exact size
			itr->status = Busy ;
			return itr->data ;
		}
		else if (size + sizeof(sm_container_t) < itr->dsize) {
			// check if there's any available hole
			min = itr->dsize;
			hole = itr;
			cond = 1;
			break;
		}
	}
	if(cond) // if there's any available hole, do best-fit
		for(itr = sm_first ; itr != 0x0 ; itr= itr->next){
			if(itr->status == Unused && size + sizeof(sm_container_t) < itr->dsize && itr->dsize < min){
				min = itr->dsize;
				hole = itr;
			}
		}

	if (hole == 0x0) {
		hole = sm_retain_more_memory(size) ;

		if (hole == 0x0)
			return 0x0 ;

		if (sm_first == 0x0) {
			sm_first = hole ;
			sm_last = hole ;
			hole->next = 0x0 ;
		}
		else {
			sm_last->next = hole ;
			sm_last = hole ;
			hole->next = 0x0 ;
		}
	}
	sm_container_split(hole, size) ;
	hole->dsize = size ;
	hole->status = Busy ;
	
	unused_linked_list();	
	
	return hole->data ;
}



void sfree(void * p)
{
	int i = 0;
	sm_container_ptr itr ;
	for (itr = sm_first ; itr->next != 0x0 ; itr = itr->next) {
		if (itr->data == p) {
			itr->status = Unused ;
			break ;
		}
	}
	unused_linked_list();
//	for(itr = sm_first; itr->next != 0x0;i++, itr = itr->next){
		merge_adjacent_unused();
//	}
}

void print_sm_uses(){
	sm_container_ptr itr;
	size_t memalloc = 0;
	size_t used = 0;
	size_t unused = 0;
	
	if(sm_first != sm_last)
		memalloc = (int)(sm_last->data - sm_first->data + sizeof(sm_container_t) + sm_last->dsize);
	for (itr = sm_first; itr != 0x0; itr = itr->next) {
		if (itr->status == Unused)
			unused = unused + (itr->dsize);
		else
			used = used + (itr->dsize);
	}

//	printf("======================= sm_uses =======================\n");
	fprintf(stderr, "Smalloc retained : %8d\n     Busy Memory : %8d\n   Unused Memory : %8d\n",(int)memalloc, (int)used, (int)unused);
//	printf("=======================================================\n");	
}

void print_sm_containers()
{
	sm_container_ptr itr ;
	int i = 0 ;

	printf("==================== sm_containers ====================\n") ;
	for (itr = sm_first ; itr != 0x0 ; itr = itr->next, i++) {
		char * s ;
		printf("%3d:%p:%s:", i, itr->data, itr->status == Unused ? "Unused" : "  Busy") ;
		printf("%8d:", (int) itr->dsize) ;

		for (s = (char *) itr->data ;
			 s < (char *) itr->data + (itr->dsize > 8 ? 8 : itr->dsize) ;
			 s++) 
			printf("%02x ", *s) ;
		printf("\n") ;
	}
	printf("=======================================================\n") ;

}
